﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiguelForm
{
    public partial class CategoriasForm : Form
    {
      string IdCategoria;
        private BaseDeDatos BaseConectada = new BaseDeDatos();
        public CategoriasForm()
        {

            InitializeComponent();
            Categoria();
        }
        // Crear Funcion para seleccionar todas las categorias y mostrarlas.
        private void Categoria()
        {
            string query = "select * from Categorias";

            using (SqlConnection conn = BaseConectada.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                IdCategoria = row.Cells["IdCategoria"].Value.ToString();
                textBox1.Text = row.Cells["Nombre"].Value.ToString();
                textBox2.Text = row.Cells["Descripcion"].Value.ToString();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            string query = "insert into Categorias (Nombre, Descripcion) values (@Nombre, @Descripcion)";

            using (SqlConnection conn = BaseConectada.Conectar())
            {

                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Nombre", textBox1.Text);
                    cmd.Parameters.AddWithValue("@Descripcion", textBox2.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se agrego la Categoria");
                    Categoria();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un error para agregar la categoria: " + ex.Message);
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string query = "update Categorias set Nombre = @Nombre, Descripcion = @Descripcion where IdCategoria =  @IdCategoria";

            using (SqlConnection conn = BaseConectada.Conectar())
            {

                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@IdCategoria", IdCategoria);
                    cmd.Parameters.AddWithValue("@Nombre", textBox1.Text);
                    cmd.Parameters.AddWithValue("@Descripcion", textBox2.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se ha actualizado la categoria");
                    Categoria();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un error al actualizar la categoria: " + ex.Message);
                }
            }
    }

        private void button8_Click(object sender, EventArgs e)
        {
            string query = "delete from Categorias where IdCategoria = @IdCategoria";

            using (SqlConnection conn = BaseConectada.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@IdCategoria", IdCategoria);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("La Categoria se elimino exitosamente");
                    Categoria();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un error al eliminar la categoria: " + ex.Message);
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
