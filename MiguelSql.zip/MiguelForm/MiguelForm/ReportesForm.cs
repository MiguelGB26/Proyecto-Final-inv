﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiguelForm
{
    public partial class ReportesForm : Form
    {
        public ReportesForm()
        {
            InitializeComponent();
            Proveedores();
            Categorias();
            Reporte();
            Consulta();
        }

        private BaseDeDatos  BaseConectadas = new BaseDeDatos();

      
        private void Proveedores()
        {
            string query = "select IdProveedor, NombreEmpresa from Proveedores";

            using (SqlConnection conn = BaseConectadas.Conectar())
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    comboBox2.DataSource = dt;
                    comboBox2.DisplayMember = "NombreEmpresa";
                    comboBox2.ValueMember = "IdProveedor"; ;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un problema al cargar proveedores: " + ex.Message);
                }
            }
        }


        private void Categorias()
        {
            string query = "select IdCategoria, Nombre from Categorias";

            using (SqlConnection conn = BaseConectadas.Conectar())
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    comboBox1.DataSource = dt;
                    comboBox1.DisplayMember = "Nombre";
                    comboBox1.ValueMember = "IdCategoria"; ;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un problema al cargar categorias: " + ex.Message);
                }
            }
        }


        private void Consulta()
        {
            string query = "SELECT p.CodigoProducto, p.NombreProduct AS NombreProducto, p.Precio, p.Cantidad AS EnExistencia, c.Nombre AS Categoria, pr.NombreEmpresa AS Proveedor, p.IdCategoria, p.IdProveedor FROM Productos p JOIN Categorias c ON p.IdCategoria = c.IdCategoria JOIN Proveedores pr ON p.IdProveedor = pr.IdProveedor WHERE p.IdCategoria = @IdCategoria AND p.IdProveedor = @IdProveedor;";

            using (SqlConnection conn = BaseConectadas.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@IdCategoria", comboBox1.SelectedValue);
                cmd.Parameters.AddWithValue("@IdProveedor", comboBox2.SelectedValue);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;
                try
                {

                }
                catch (Exception)
                {
                    MessageBox.Show("Primero debe existir Proveedores y Categorias: ");
                }
            }
        }


        private void Reporte()
        {
            string query = "SELECT p.CodigoProducto, p.NombreProduct AS NombreProducto, p.Precio, p.Cantidad AS EnExistencia, c.Nombre AS Categoria, pr.NombreEmpresa AS Proveedor, p.IdCategoria, p.IdProveedor FROM Productos p JOIN Categorias c ON p.IdCategoria = c.IdCategoria JOIN Proveedores pr ON p.IdProveedor = pr.IdProveedor WHERE p.Cantidad < 10;\r\n";

            using (SqlConnection conn = BaseConectadas.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView2.DataSource = dt;
                try
                {

                }
                catch (Exception)
                {
                    MessageBox.Show("Primero debe existir Proveedores y Categorias: ");
                }
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Consulta();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ReportesForm_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        
    }
}
