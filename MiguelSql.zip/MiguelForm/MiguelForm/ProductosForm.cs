﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MiguelForm
{
    public partial class ProductosForm : Form
    {
        string CodigoProducto;
        private BaseDeDatos Conectarbase = new BaseDeDatos();

        private void Productos()
        {
            string query = "SELECT * FROM Productos"; // Cambia por tu query adecuado
            using (SqlConnection conn = Conectarbase.Conectar())
            {
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void Proveedores()
        {
            string query = "select IdProveedor, NombreEmpresa from Proveedores";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    comboBox3.DataSource = dt;
                    comboBox3.DisplayMember = "NombreEmpresa";
                    comboBox3.ValueMember = "IdProveedor"; ;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un problema al cargar proveedores: " + ex.Message);
                }
            }
        }

        //Cargar Categorias
        private void Categorias()
        {
            string query = "select IdCategoria, Nombre from Categorias";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    comboBox2.DataSource = dt;
                    comboBox2.DisplayMember = "Nombre";
                    comboBox2.ValueMember = "IdCategoria"; ;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hubo un problema al cargar categorias: " + ex.Message);
                }
            }
        }
        public ProductosForm()
        {

                InitializeComponent(); // Debe ir primero
                Categorias();
                Proveedores();
                Productos();
            

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                CodigoProducto = row.Cells["CodigoProducto"].Value.ToString();
                textBox1.Text = row.Cells["NombreProduct"].Value.ToString();
                textBox2.Text = row.Cells["Precio"].Value.ToString();
                textBox3.Text = row.Cells["Cantidad"].Value.ToString();
                comboBox2.SelectedValue = row.Cells["IdCategoria"].Value;
                comboBox3.SelectedValue = row.Cells["IdProveedor"].Value;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Productos (NombreProduct, Precio, Cantidad, IdCategoria, IdProveedor) VALUES (@Nombre, @Precio, @EnExistencia, @IdCategoria, @IdProveedor)";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Nombre", textBox1.Text);
                cmd.Parameters.AddWithValue("@Precio", textBox2.Text);
                cmd.Parameters.AddWithValue("@EnExistencia", textBox3.Text);
                cmd.Parameters.AddWithValue("@IdCategoria", comboBox2.SelectedValue);
                cmd.Parameters.AddWithValue("@IdProveedor", comboBox3.SelectedValue);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Producto agregado");
                Productos();  // Para recargar la lista de productos
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Productos WHERE CodigoProducto = @CodigoProducto";

            using (SqlConnection conn = Conectarbase.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CodigoProducto", CodigoProducto); // Contenedor de código del producto
                cmd.ExecuteNonQuery();
                MessageBox.Show("Producto eliminado");
                Productos();  // Para recargar la lista de productos
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
