﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace MiguelForm
{
    public class BaseDeDatos
    {
        private static string connectionString = "Server=localhost\\SQLEXPRESS; Initial Catalog=tarea2222; Integrated Security=True;";

        public SqlConnection Conectar()
        {
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                conn.Open();
                return conn;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al conectar a la base de datos: " + ex.Message);
            }
        }
    }
}
